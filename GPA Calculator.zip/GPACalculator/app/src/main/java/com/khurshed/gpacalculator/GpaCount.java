package com.khurshed.gpacalculator;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import static java.lang.String.format;

public class GpaCount extends AppCompatActivity {
    EditText credit, gpa;
    TextView res;
    double counter=0, total_C=0,credit1=0, grade =0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gpa_count);
        credit = findViewById(R.id.editText1);
        gpa = findViewById(R.id.editText2);
        res = findViewById(R.id.result);

        //bottom nav
        BottomNavigationView bottomNavigationView;
        bottomNavigationView = (BottomNavigationView) findViewById(R.id.navbar);
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId())
                {
                    case R.id.moreApp:
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse("https://play.google.com/store/search?q=gpa%20calculator&c=apps"));
                        startActivity(intent);
                        break;
                        
                    case R.id.rateIt:
                        Toast.makeText(GpaCount.this, "We haven't published our app yet", Toast.LENGTH_SHORT).show();
                        break;
                }
                return false;
            }
        });
    }

    public void addCoursebtn(View view) {
        credit1 = Double.parseDouble(credit.getText().toString());
        grade = Double.parseDouble(gpa.getText().toString());
        counter+= (grade*credit1);

        total_C += credit1;
        //res.setText("%.2f"+counter/total_C);
        res.setText(String.format("%.2f",+counter/total_C));
        credit.setText("");
        gpa.setText("");
        Toast.makeText(this, "Course Added", Toast.LENGTH_SHORT).show();

    }

    public void calculatebtn(View view) {
        double result1 = counter/total_C;

        //res.setText(""+result1);
        res.setText(String.format("%.2f",+result1));
        Toast.makeText(this, "GPA: "+result1, Toast.LENGTH_SHORT).show();
    }

    public void erasebtn(View view) {
        counter = 0;
        total_C =0;
        credit1 =0;
        grade =0;
        gpa.setText("");
        res.setText("");
        credit.setText("");
    }
}